"""
Random Forest comparison
author: li zeng
"""

# ██ ███    ███ ██████   ██████  ██████  ████████
# ██ ████  ████ ██   ██ ██    ██ ██   ██    ██
# ██ ██ ████ ██ ██████  ██    ██ ██████     ██
# ██ ██  ██  ██ ██      ██    ██ ██   ██    ██
# ██ ██      ██ ██       ██████  ██   ██    ██

import os
import sys
sys.path.append(os.path.realpath('../PKB'))

import assist
import numpy as np
from sklearn import ensemble
from sys import argv
import pickle


# ██ ███    ██ ██████  ██    ██ ████████
# ██ ████   ██ ██   ██ ██    ██    ██
# ██ ██ ██  ██ ██████  ██    ██    ██
# ██ ██  ██ ██ ██      ██    ██    ██
# ██ ██   ████ ██       ██████     ██

# set random seed
np.random.seed(1)
njobs = 2

config_file = argv[1]
outfolder = argv[2]

print("input file:",config_file)
print()

inputs = assist.input_process.input_obj()
inputs.proc_input(config_file)
inputs.data_preprocessing(rm_lowvar=False,norm=False)

# input summary
print()
inputs.input_summary()
print()


# ██████  ███████
# ██   ██ ██
# ██████  █████
# ██   ██ ██
# ██   ██ ██


out_obs = []
for i in range(3):
    test_lab = inputs.input_folder+'/test_label'+str(i)+'.txt'
    f  = open(test_lab,'r')
    test_ind = [x.strip() for x in f]
    f.close()
    train_ind = np.setdiff1d(inputs.train_predictors.index.values,np.array(test_ind))    
                                               
    Xtrain = inputs.train_predictors.loc[train_ind]
    ytrain = inputs.train_response.loc[train_ind]
    Xtest = inputs.train_predictors.loc[test_ind]
    ytest = inputs.train_response.loc[test_ind]
    rf_fit = ensemble.RandomForestClassifier(n_estimators=800,verbose=1,n_jobs=njobs)
    rf_fit.fit(Xtrain,ytrain)
    # prediction error
    err = 1-rf_fit.score(Xtest,ytest)
    imp = rf_fit.feature_importances_
    out_obs.append([err,imp])    
    

# ███████  █████  ██    ██ ███████
# ██      ██   ██ ██    ██ ██
# ███████ ███████ ██    ██ █████
#      ██ ██   ██  ██  ██  ██
# ███████ ██   ██   ████   ███████
if not os.path.exists(outfolder):
    os.makedirs(outfolder)

out_file = outfolder + "/results.pckl"
f = open(out_file,'wb')
pickle.dump([err,rf_fit],f)
f.close()
print("results saved to:",out_file)

f = open(outfolder+'/report.txt','w')
f.write("prediction error: "+str([x[0] for x in out_obs]) )
f.close()
