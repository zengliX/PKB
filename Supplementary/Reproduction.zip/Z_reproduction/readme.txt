This file contains the instructions for reproducing the results in our paper.

Software preparations:
- PKB:  Python3. Please refer to https://github.com/zengliX/PKB for more computation requirements for using PKB
- SVM, RandomForest: Python3, sklearn python module
- EasyMKL: Python2, MKLpy module downloaded from https://pypi.python.org/pypi/MKLpy
- NPR: R: rpart package


Since both real data and simulation data are large, please send a request to email address  li.zeng@yale.edu if you need them.
Before running all python programs, remember to add the PKB folder to your Python search path.

####################################
#### reproducing PKB results ########
####################################

# change directory to the PKB folder

cd PKB

# produce the results using corresponding commands in the files of folder PKB/scripts 
# for example:

python -u PKB.py "../simulations/simu_N900_M50_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt" test_label0.txt 1 2&> simu_N900_M50_case1_rate0.1_rand1_Lam0.1_poly3_L1.out
python -u PKB.py "../simulations/simu_N900_M50_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt" test_label1.txt 1 2&> simu_N900_M50_case1_rate0.1_rand1_Lam0.1_poly3_L1.out
python -u PKB.py "../simulations/simu_N900_M50_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt" test_label2.txt 1 2&> simu_N900_M50_case1_rate0.1_rand1_Lam0.1_poly3_L1.out

####################################
#### reproducing RandomForest results ########
####################################

# change directory to RandomForest
cd RandomForest

# simulation results

python RandomForest.py ../simulations/simu_N900_M50_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case1
python RandomForest.py ../simulations/simu_N900_M150_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case1
python RandomForest.py ../simulations/simu_N900_M50_case2/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case2
python RandomForest.py ../simulations/simu_N900_M150_case2/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case2
python RandomForest.py ../simulations/simu_N900_M50_case3/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case3
python RandomForest.py ../simulations/simu_N900_M150_case3/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case3

# real data results
python -u RandomForest.py ../data/Brain/cleaned/config_rate0.01_Biocarta_Lam0.1_poly3_sub1_L1_pen0.2.txt Brain_grade
python -u RandomForest.py ../data/Brain/cleaned_site/config_rate0.01_Biocarta_Lam0.1_poly3_sub1_L1_pen0.2.txt Brain_site
python -u RandomForest.py ../data/melanoma/cleaned_stage/config_rate0.01_KEGG_Lam0.1_poly3_sub1_L1_pen0.2.txt melanoma_stage
python -u RandomForest.py ../data/melanoma/cleaned_met/config_rate0.01_KEGG_Lam0.1_poly3_sub1_L1_pen0.2.txt melanoma_met
python -u RandomForest.py ../data/Metabric/cleaned_LumB_grade/config_rate0.02_Biocarta_Lam0.1_poly3_sub1_L1.txt Metabric_LumB_grade

####################################
#### reproducing SVM results ########
####################################

# change directory to SVM
cd SVM

# simulation results

python SVM.py ../simulations/simu_N900_M50_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case1
python SVM.py ../simulations/simu_N900_M150_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case1
python SVM.py ../simulations/simu_N900_M50_case2/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case2
python SVM.py ../simulations/simu_N900_M150_case2/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case2
python SVM.py ../simulations/simu_N900_M50_case3/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case3
python SVM.py ../simulations/simu_N900_M150_case3/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case3

# real data results
python -u SVM.py ../data/Metabric/cleaned_LumB_grade/config_rate0.01_Biocarta_Lam0.1_poly3_sub1_L1_pen0.2.txt Metabric_LumB_grade
python -u SVM.py ../data/Brain/cleaned/config_rate0.01_Biocarta_Lam0.1_poly3_sub1_L1_pen0.2.txt Brain_grade
python -u SVM.py ../data/Brain/cleaned_site/config_rate0.01_Biocarta_Lam0.1_poly3_sub1_L1_pen0.2.txt Brain_site
python -u SVM.py ../data/melanoma/cleaned_stage/config_rate0.01_KEGG_Lam0.1_poly3_sub1_L1_pen0.2.txt melanoma_stage 
python -u SVM.py ../data/melanoma/cleaned_met/config_rate0.01_KEGG_Lam0.1_poly3_sub1_L1_pen0.2.txt melanoma_met 

####################################
#### reproducing EasyMKL results ########
####################################

# change directory to MKL
cd MKL

# since MKLpy module only works in Python2 environment, you need to activate Python2 for the following commands
# simulation results
python MKL.py ../simulations/simu_N900_M50_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case1/rbf rbf
python MKL.py ../simulations/simu_N900_M150_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case1/rbf rbf
python MKL.py ../simulations/simu_N900_M50_case2/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case2/rbf rbf
python MKL.py ../simulations/simu_N900_M150_case2/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case2/rbf rbf
python MKL.py ../simulations/simu_N900_M50_case3/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case3/rbf rbf
python MKL.py ../simulations/simu_N900_M150_case3/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case3/rbf rbf
python MKL.py ../simulations/simu_N900_M50_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case1/poly3 poly3
python MKL.py ../simulations/simu_N900_M150_case1/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case1/poly3 poly3
python MKL.py ../simulations/simu_N900_M50_case2/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case2/poly3 poly3
python MKL.py ../simulations/simu_N900_M150_case2/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case2/poly3 poly3
python MKL.py ../simulations/simu_N900_M50_case3/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M50_case3/poly3 poly3
python MKL.py ../simulations/simu_N900_M150_case3/config_rate0.1_rand1_Lam0.1_poly3_L1.txt simu_N900_M150_case3/poly3 poly3

# produce real data results using corresponding commands in the files of folder MKL/scripts 

####################################
#### reproducing NPR results ########
####################################

# change directory to NPR
cd NPR
# simulation results
bash npr_simu.sh simu_N900_M150_case1
bash npr_simu.sh simu_N900_M150_case2
bash npr_simu.sh simu_N900_M150_case3
bash npr_simu.sh simu_N900_M50_case1
bash npr_simu.sh simu_N900_M50_case2
bash npr_simu.sh simu_N900_M50_case3 
# real data results
# Brain Grade
bash npr.sh Brain/cleaned KEGG
bash npr.sh Brain/cleaned Biocarta
# Brain Site
bash npr.sh Brain/cleaned_site KEGG
bash npr.sh Brain/cleaned_site Biocarta
# Melanoma Met
bash npr.sh melanoma/cleaned_met KEGG
bash npr.sh melanoma/cleaned_met Biocarta
# Melanoma Stage
bash npr.sh melanoma/cleaned_stage KEGG
bash npr.sh melanoma/cleaned_stage Biocarta
# Metabric Grade
bash npr.sh Metabric/cleaned_LumB_grade KEGG
bash npr.sh Metabric/cleaned_LumB_grade Biocarta

# other command lines are in the scripts folder 

# collect the results
cd results
bash collect_res.sh simulations
bash collect_res.sh Brain_cleaned
bash collect_res.sh Brain_cleaned_site
bash collect_res.sh melanoma_cleaned_met
bash collect_res.sh melanoma_cleaned_stage
bash collect_res.sh Metabric_cleaned_LumB_grade

