"""
Random Forest comparison
author: li zeng
"""

# ██ ███    ███ ██████   ██████  ██████  ████████
# ██ ████  ████ ██   ██ ██    ██ ██   ██    ██
# ██ ██ ████ ██ ██████  ██    ██ ██████     ██
# ██ ██  ██  ██ ██      ██    ██ ██   ██    ██
# ██ ██      ██ ██       ██████  ██   ██    ██

import os


import sys
sys.path.append(os.path.realpath('../PKB'))

import assist
import numpy as np
from sklearn import svm
from sys import argv
import pickle



# ██ ███    ██ ██████  ██    ██ ████████
# ██ ████   ██ ██   ██ ██    ██    ██
# ██ ██ ██  ██ ██████  ██    ██    ██
# ██ ██  ██ ██ ██      ██    ██    ██
# ██ ██   ████ ██       ██████     ██

# set random seed
np.random.seed(1)

#config_file = "../simulations/simu_N300_M15_case1/config1_sub100_poly2.txt"
#outfolder = "simu_N300_M15_case1"
config_file = argv[1]
outfolder = argv[2]

print("input file:",config_file)
print()

inputs = assist.input_process.input_obj()
inputs.proc_input(config_file)
inputs.data_preprocessing(rm_lowvar=False,norm=False)

# input summary
print()
inputs.input_summary()
print()




# ███████ ██    ██ ███    ███
# ██      ██    ██ ████  ████
# ███████ ██    ██ ██ ████ ██
#      ██  ██  ██  ██  ██  ██
# ███████   ████   ██      ██


classifiers = {}
for i in range(3):
    test_lab = inputs.input_folder+'/test_label'+str(i)+'.txt'
    print("working on "+test_lab+'\n')
    f  = open(test_lab,'r')
    test_ind = [x.strip() for x in f]
    f.close()
    train_ind = np.setdiff1d(inputs.train_predictors.index.values,np.array(test_ind))    
                                               
    Xtrain = inputs.train_predictors.loc[train_ind]
    ytrain = inputs.train_response.loc[train_ind]
    Xtest = inputs.train_predictors.loc[test_ind]
    ytest = inputs.train_response.loc[test_ind]

    for c in [.05,.5,5,50]:
        for k in ['rbf','poly3']:
            if k=='rbf':
                svm_fit = svm.SVC(C = c,kernel='rbf')
            elif k=='poly2':
                svm_fit = svm.SVC(C = c,kernel='poly',degree=2)
            elif k=='poly3':
                svm_fit = svm.SVC(C = c,kernel='poly',degree=3)
            svm_fit.fit(Xtrain,ytrain)
            err = 1 - svm_fit.score(Xtest,ytest)
            if classifiers.get((c,k)):
                classifiers[(c,k)].append(err)
            else:
                classifiers[(c,k)] = [err]

best_err = 1
for i in classifiers.items():
    m = np.mean(i[1])
    if m < best_err:
        best_err = m
    classifiers[i[0]] = [i[1],m ]

# ███████  █████  ██    ██ ███████
# ██      ██   ██ ██    ██ ██
# ███████ ███████ ██    ██ █████
#      ██ ██   ██  ██  ██  ██
# ███████ ██   ██   ████   ███████
if not os.path.exists(outfolder):
    os.makedirs(outfolder)

out_file = outfolder + "/results.pckl"
f = open(out_file,'wb')
pickle.dump(classifiers,f)
f.close()
print("results saved to:",out_file)

f = open(outfolder+'/report.txt','w')
for i in classifiers.items():
    f.write(str(i[0])+': '+str(i[1])+'\n')
f.write('best_err: '+str(best_err))
f.close()
