# -*- coding: utf-8 -*-
"""
main program
author: li zeng
"""

# ██ ███    ███ ██████   ██████  ██████  ████████
# ██ ████  ████ ██   ██ ██    ██ ██   ██    ██
# ██ ██ ████ ██ ██████  ██    ██ ██████     ██
# ██ ██  ██  ██ ██      ██    ██ ██   ██    ██
# ██ ██      ██ ██       ██████  ██   ██    ██

import os

import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import assist
from assist.functions import loss_fun, line_search
from assist.cvPKB import CV_PKB
from assist.method_L1 import oneiter_L1, find_Lambda_L1
from assist.method_L2 import oneiter_L2, find_Lambda_L2
import numpy as np
import time
from multiprocessing import cpu_count
from sys import argv
import sharedmem

    
# ██ ███    ██ ██████  ██    ██ ████████
# ██ ████   ██ ██   ██ ██    ██    ██
# ██ ██ ██  ██ ██████  ██    ██    ██
# ██ ██  ██ ██ ██      ██    ██    ██
# ██ ██   ████ ██       ██████     ██

# set random seed
np.random.seed(1)
config_file = argv[1]
arg2 = argv[2]
pen = float(argv[3])

print("input file:",config_file)
inputs = assist.input_process.input_obj()
inputs.proc_input(config_file)
inputs.data_preprocessing(rm_lowvar=False,center=True,norm=False)


"""---------------------------
SPLIT TEST TRAIN
----------------------------"""

# use testing labels
test_lab = inputs.input_folder+'/'+arg2
assist.input_process.have_file(test_lab)
f  = open(test_lab,'r')
test_ind = [x.strip() for x in f]
f.close()

temp = inputs.output_folder+'/'+arg2.split('.')[0]
if not os.path.exists(temp):
    os.mkdir(temp)
inputs.output_folder = temp

# change training and testing 
inputs.test_predictors = inputs.train_predictors.loc[test_ind]
inputs.test_response = inputs.train_response.loc[test_ind]
train_ind = np.setdiff1d(inputs.train_predictors.index.values,np.array(test_ind))
inputs.train_predictors = inputs.train_predictors.loc[train_ind]
inputs.train_response = inputs.train_response.loc[train_ind]

inputs.Ntest = len(inputs.test_response)
inputs.Ntrain = len(inputs.train_response)


# input summary
print()
inputs.input_summary()
inputs.model_param()
print("number of cpus available:",cpu_count())
print()


# ██████  ██    ██ ███    ██      █████  ██       ██████   ██████
# ██   ██ ██    ██ ████   ██     ██   ██ ██      ██       ██    ██
# ██████  ██    ██ ██ ██  ██     ███████ ██      ██   ███ ██    ██
# ██   ██ ██    ██ ██  ██ ██     ██   ██ ██      ██    ██ ██    ██
# ██   ██  ██████  ██   ████     ██   ██ ███████  ██████   ██████

"""---------------------------
CALCULATE KERNEL
----------------------------"""
#importlib.reload(assist.kernel_calc)
K_train = assist.kernel_calc.get_kernels(inputs.train_predictors,inputs.train_predictors,inputs)
if inputs.Ntest > 0:
    K_test= assist.kernel_calc.get_kernels(inputs.train_predictors,inputs.test_predictors,inputs)

# put K_train in shared memory
sharedK = sharedmem.empty(K_train.size)
sharedK[:] = np.transpose(K_train,(2,0,1)).reshape((K_train.size,))
Kdims = (K_train.shape[0],K_train.shape[2])


"""---------------------------
initialize outputs object
----------------------------"""
#importlib.reload(assist.outputs)
outputs = assist.outputs.output_obj(inputs)

ytrain = np.squeeze(inputs.train_response.values)
N1 = (ytrain == 1).sum()
N0 = (ytrain ==-1).sum()
F0 = np.log(N1/N0) # initial value
if F0==0: F0+=10**(-2)
outputs.F0 = F0

F_train = np.repeat(F0,inputs.Ntrain) # keep track of F_t(x_i) on training data
outputs.train_err.append((np.sign(F_train) != ytrain).sum()/len(ytrain))
outputs.train_loss.append(loss_fun(F_train,ytrain))
if not inputs.Ntest == None:
    ytest = np.squeeze(inputs.test_response.values)
    F_test = np.repeat(F0,inputs.Ntest) # keep track of F_t(x_i) on testing data
    outputs.test_err.append((np.sign(F_test) != ytest).sum()/len(ytest))
    outputs.test_loss.append(loss_fun(F_test,ytest))
    
outputs.trace.append([0,np.repeat(0,inputs.Ntrain),0])


# ██████   ██████   ██████  ███████ ████████ ██ ███    ██  ██████
# ██   ██ ██    ██ ██    ██ ██         ██    ██ ████   ██ ██
# ██████  ██    ██ ██    ██ ███████    ██    ██ ██ ██  ██ ██   ███
# ██   ██ ██    ██ ██    ██      ██    ██    ██ ██  ██ ██ ██    ██
# ██████   ██████   ██████  ███████    ██    ██ ██   ████  ██████
"""---------------------------
BOOSTING PARAMETERS
----------------------------"""
ncpu = min(5,cpu_count())
Lambda = inputs.Lambda

# automatic selection of Lambda
if inputs.method == 'L1' and Lambda is None: 
    Lambda = find_Lambda_L1(K_train,F_train,ytrain,Kdims)
    Lambda *= pen
    print("L1 method: use Lambda",Lambda)
if inputs.method == 'L2' and Lambda is None:
    Lambda = find_Lambda_L2(K_train,F_train,ytrain,Kdims,C=1)
    Lambda *= pen
    print("L2 method: use Lambda",Lambda)

# is there a need to run parallel
if (inputs.Ntrain > 500 or inputs.Ngroup > 40):
    parallel = True
    print("Algorithm: parallel on",ncpu,"cores")
    gr_sub = True
    print("Algorithm: random groups selected in each iteration")
else:
    parallel = False
    gr_sub = False
    print("Algorithm: parallel algorithm not used")


ESTOP = 100 # early stop if test_loss have no increase
"""---------------------------
CV FOR NUMBER OF ITERATIONS
----------------------------"""
opt_iter = CV_PKB(inputs,sharedK,K_train,Kdims,Lambda,nfold=3,ESTOP=ESTOP,\
                  ncpu=1,parallel=False,gr_sub=False,plot=True)
"""---------------------------
BOOSTING ITERATIONS
----------------------------"""

time0 = time.time()
print("--------------------- Boosting ------------------------")
print("iteration\ttrain err\ttest err\t    time")
for t in range(1,opt_iter+1):
    # one iteration
    if inputs.method == 'L2':
        [m,beta,c] = oneiter_L2(sharedK,F_train,ytrain,Kdims,\
                Lambda=Lambda,ncpu = ncpu,parallel = parallel,\
                sele_loc=None,group_subset = gr_sub)    
    if inputs.method == 'L1':
        [m,beta,c] = oneiter_L1(sharedK,F_train,ytrain,Kdims,\
                Lambda=Lambda,ncpu = ncpu,parallel = parallel,\
                sele_loc=None,group_subset = gr_sub) 
    
    # line search
    x = line_search(sharedK,F_train,ytrain,Kdims,[m,beta,c])
    beta *= x
    c *= x
    
    # update outputs
    outputs.trace.append([m,beta,c])
    F_train += (K_train[:,:,m].dot(beta) + c)*inputs.nu
    outputs.train_err.append((np.sign(F_train)!=ytrain).sum()/len(ytrain))
    outputs.train_loss.append(loss_fun(F_train,ytrain))
    if inputs.Ntest>0:
        F_test += (K_test[:,:,m].T.dot(beta)+ c)*inputs.nu
        outputs.test_err.append((np.sign(F_test)!=ytest).sum()/len(ytest))
        new_loss = loss_fun(F_test,ytest)
        outputs.test_loss.append(loss_fun(F_test,ytest))
                   
    # print time report
    if t%20 == 0:
        iter_persec = t/(time.time() - time0) # time of one iteration
        rem_time = (opt_iter-t)/iter_persec # remaining time
        print("%9.0f\t%9.4f\t%8.4f\t%8.4f" % \
              (t,outputs.train_err[t],outputs.test_err[t],rem_time/60))
print("-------------------------------------------------------")



# ██████  ███████ ███████ ██    ██ ██   ████████ ███████
# ██   ██ ██      ██      ██    ██ ██      ██    ██
# ██████  █████   ███████ ██    ██ ██      ██    ███████
# ██   ██ ██           ██ ██    ██ ██      ██         ██
# ██   ██ ███████ ███████  ██████  ███████ ██    ███████

## show results
    # trace
f = outputs.show_err()
f.savefig(inputs.output_folder + "/err.pdf")
f = outputs.show_loss()
f.savefig(inputs.output_folder + "/loss.pdf")

    # opt weights
[weights,f0] = outputs.group_weights(opt_iter-1,plot=True)
f0.savefig(inputs.output_folder + "/opt_weights.pdf")

    # weights paths
[path_mat,f1] = outputs.weights_path(plot=True)
f1.savefig(inputs.output_folder + "/weights_path.pdf")


# ███████  █████  ██    ██ ███████
# ██      ██   ██ ██    ██ ██
# ███████ ███████ ██    ██ █████
#      ██ ██   ██  ██  ██  ██
# ███████ ██   ██   ████   ███████

# save outputs to files
import pickle
out_file = inputs.output_folder + "/results.pckl"
f = open(out_file,'wb')
outputs.inputs.test_predictors =None
outputs.inputs.train_predictors = None
outputs.inputs.test_response=None
outputs.inputs.train_response=None
outputs.inputs.pred_sets=None
pickle.dump(outputs,f)
f.close()
print("results saved to:",out_file)


