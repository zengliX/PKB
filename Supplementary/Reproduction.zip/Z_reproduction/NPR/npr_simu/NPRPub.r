# Please set your options here.  You may set those options which have
# comments.   Please refer to the readme file for a discription of the sample data.
# 
# options
# NPRPub.r --arg 
#   dataset[Metabric|TCGA_LUNG|TCGA_LUNG_NORMAL]
#   pathway_file[KEGG|Panther|...]   
#   cv_num[0|1|2]
#   M[integer]

# argument reading
arg <- commandArgs(trailingOnly = T)

dataset <- arg[1]

pathway_file <- paste("../simulations/",arg[1],"/predictor_sets.txt", sep = "")

cv_num <- arg[2]

M <- as.numeric(arg[3])

output_directory <- paste("./results/simulations/",dataset,"/",sep = "")
if (!dir.exists(output_directory)) {
  dir.create(output_directory)

}



#Pathway Information
source("./npr_simu/npr_app.R")
#Pathways <-list()
  #Set Your own pathway here; xi is the ith feature index in your dataset
#    Pathways[[1]] <- c("x1","x2","x3","x4","x5","x6","x7","x8","x9","x10")           #Pathway 1    
#    Pathways[[2]] <- c("x11","x12","x13","x14","x15","x16","x17","x18","x19","x20")  #Pathway 2
#    Pathways[[3]] <- c("x21","x22","x23","x24","x25","x26","x27","x28","x29","x30")  #Pathway 3    
#    Pathways[[4]] <- c("x31","x32","x33","x34","x35","x36","x37","x38","x39","x40")  #Pathway 4
#    Pathways[[5]] <- c("x41","x42","x43","x44","x45","x46","x47","x48","x49","x50")  #Pathway 5

expression_file <- paste("../simulations/",dataset,"/predictor.txt",sep = "")
pathway_info <- read_pathway(pathway_file) 
Pathways <- convert_features(expression_file,pathway_info$pathway_list)
exp_fi <- file(expression_file,open="r")


# Generate the training and testing files
setwd(output_directory)
datafile_list <- files_generation(dataset, cv_num)

#Tranining Data file and testing Data file
#trainingFile <- paste("trainingData",cv_num,".txt", sep = "")
#testingFile  <- paste("testingData",cv_num,".txt", sep = "")   
trainingFile <- datafile_list$training_name
testingFile <- datafile_list$testing_name


# The Number of non-redudant Features in your data
NumofX <- length(strsplit(readLines(exp_fi, n = 1),",")[[1]]) - 1

# The Number of Pathways in your dataset
K <- length(Pathways) 

#M <- 30          # Maximum Boosting Step
# A key parameter. A good way to set it is according to cross validation
# Much dependent on Shrinkage; The smaller Shrinkage, the larger M.

Shrinkage <- 0.01 # Shrinkage coefficient during Boosting procedure; a positive <=1.0
# 0.01 is the default value, should work for most cases
# Basically the smaller, the more boosting steps (more running time) needed
# the smaller, the finer tuning, and the better results are expected.

#Options for the tree base learner 

MaxDepth <- 2   # Maximum Depth of rpart tree; Depth=2 is suggested.
library("rpart")
rControl <- rpart.control(maxdepth=MaxDepth,maxcompete=0,maxsurrogate=0)


             
#Output file name
Outputfile <- paste("SampleOutput",cv_num,".txt", sep = "")
source("../../../npr_simu/NPRmain.r")
