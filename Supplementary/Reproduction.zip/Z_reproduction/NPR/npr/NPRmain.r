


########Training Rou Function #############


# trainingN <- number of training samples
# M <- iteration number
training_mainfunction <- function(trainingData, testingData)
{
  
  trainingN = dim(trainingData)[1]
  fx = rep(0,trainingN*(M+1))
  dim(fx)= c(trainingN,M+1)
  
  testingN  = dim(testingData)[1]
  testingFx = rep(0,testingN*(M+1))
  dim(testingFx)= c(testingN,M+1)
  
  trainingTrueY=trainingData[,"Y"]
  testingTrueY=testingData[,"Y"]
  
  # initialize the importance score
  # NumofX <- number of features
  FeatureImportance<-list()
  for (i in 1:NumofX){
    FeatureImportance[paste("x",i,sep='')]=0
  }
  
  
  SelectedPathways=vector(mode="numeric", length=M)
  PathwayImportance=vector(mode="numeric", length=K)
  trainingError=vector(mode="numeric", length=M)
  testingError=vector(mode="numeric", length=M)
  Testing=c()
  
  #Generate the formula based on pathway information
  fmla<-list()
  for (i in 1:length(Pathways)){
    fmla[[i]]=as.formula(paste("trainingData[,\"Y\"] ~ ", paste(Pathways[[i]], collapse= "+")))
  }
  
  ##Boosting...
  
  for (m in 1:M) {
    cat(paste(m, "done.\n"))
    # Calculate the Accuracy of current boosting step
    # encoding (> 0.5) -> 1 or (<= 0.5) -> -1
    # Training Accuracy
    accuracy=as.numeric(1/(1+exp(-2*fx[,m]))>0.5)*2-1
    accuracy=sum(as.numeric(accuracy==trainingTrueY))/trainingN
    trainingError[m]=1-accuracy
    
    # Testing Accuracy
    accuracy=as.numeric(1/(1+exp(-2*testingFx[,m]))>0.5)*2-1
    Testing = cbind(Testing, accuracy)
    accuracy=sum(as.numeric(accuracy==testingTrueY))/testingN
    testingError[m]=1-accuracy
    
    # Calculate the pseudo response
    
    pseudoY=2*trainingTrueY/(1+exp(2*trainingTrueY*fx[,m]))
    trainingData[,"Y"]=pseudoY
    
    fit <- list()
    h <- list()
    testingH <-list()
    fro <- function(ro){ ## Ro function
      hmatrix = c(h[[maxk]])
      sum(log(1+exp(-2*trainingTrueY*(fx[,m]+matrix(hmatrix,nrow=trainingN,ncol=1)*ro))))
    }
    
    grr <- function(ro){ ## Gradient function of Ro
      hmatrix = c(h[[maxk]])
      expv=exp(-2*trainingTrueY*(fx[,m]+matrix(hmatrix,nrow=trainingN,ncol=1)*ro))
      gradient <- c(sum(-2*trainingTrueY*h[[maxk]]*expv/(1+expv)))		
      gradient
    }
    maxImprove=0
    maxk=-1
    
    allPws=c(1:K)
    allPws=sample(allPws)  # eliminate potential bias when more than 2 maximum pathway
    #Loop to find the pathway with the maximum improvement
    for (k in allPws) {
      #cat(k)
      #cat("\n")
      if (fmla[[k]] != 'trainingData[, "Y"] ~ x'){
        
        fit[[k]] = rpart(fmla[[k]], data=trainingData, control=rControl)
        h[[k]] = predict(fit[[k]])
        testingH[[k]]=predict(fit[[k]],testingData)
        
        if (length(fit[[k]]$splits[,"improve"])>0){
          # calculate the sum of the improvements
          if (sum(fit[[k]]$splits[,"improve"])>maxImprove) {
            maxImprove = sum(fit[[k]]$splits[,"improve"])
            maxk=k
          }
        }
      }
    }
    SelectedPathways[m]=maxk
    # default maxk is -1
    if(maxk>0){	
      # Pathway Importances
      PathwayImportance[maxk]=PathwayImportance[maxk]+maxImprove
      # Feature Importances
      selectedFeatures <- fit[[maxk]]$splits[,"improve"]
      sfNames = dimnames(fit[[maxk]]$splits)[[1]]
      if (length(selectedFeatures)>0) {
        selectedFeatures=selectedFeatures^2
        for(i in 1:length(selectedFeatures)){
          increase=selectedFeatures[i]-selectedFeatures[1]
          if (increase>0) {
            FeatureImportance[sfNames[1]]=increase/2+as.numeric(FeatureImportance[sfNames[1]])
            FeatureImportance[sfNames[i]]=selectedFeatures[i]-increase/2+as.numeric(FeatureImportance[sfNames[i]]) 
          }   else {
            FeatureImportance[sfNames[i]]=selectedFeatures[i]+as.numeric(FeatureImportance[sfNames[i]]) 
          }
        }
      }
      
      ##training...
      ro0=0
      ro=optim(ro0, fro, grr, method = "BFGS")$par
      hmatrix = c(h[[maxk]])
      fx[,m+1] = fx[,m] + Shrinkage*matrix(hmatrix,nrow=trainingN,ncol=1)*ro
      ##testing...
      hmatrix = c(testingH[[maxk]])
      testingFx[,m+1]=testingFx[,m]+Shrinkage*matrix(hmatrix,nrow=testingN,ncol=1)*ro
    } else {
      break
    } 
  }
  
  range=c(1:m)
  #End of Boosting
  
  ImportantFeatures=c()
  FeatureNames=c()
  for (i in 1:NumofX){
    FeatureNames=c(FeatureNames, paste("x",i,sep=''))
    quan = as.numeric(FeatureImportance[paste("x",i,sep='')])
    ImportantFeatures=c(ImportantFeatures,quan)
  }
  names(ImportantFeatures)=FeatureNames
  
  RelativePathwayImportance=PathwayImportance/max(PathwayImportance)
  ImportantFeatures=ImportantFeatures/max(ImportantFeatures)
  
  
  All=cbind(trainingError[range],testingError[range],SelectedPathways[range])
  colnames(All)=c("trainingError","testingError","SelectedPathway")
  rownames(All)=c(paste("Step", (range), sep=""))
  
  #write.table(All, file = Outputfile)
  ImportantFeatures=data.frame(ImportantFeatures)
  colnames(ImportantFeatures)=c("RelativeImportance")
  
  #write.table(ImportantFeatures, file = paste(Outputfile,"features",sep="."))
  RelativePathwayImportance=data.frame(RelativePathwayImportance)
  colnames(RelativePathwayImportance)=c("RelativeImportance")
  rownames(RelativePathwayImportance)=c(paste("Pathway", c(1:K), sep=""))
  #write.table(RelativePathwayImportance, file = paste(Outputfile,"pathways",sep="."))
  result_list <- list()
  result_list[["All"]] <- All
  result_list[["RelativeImportance"]] <- RelativePathwayImportance
  result_list[["ImportantFeatures"]] <- ImportantFeatures
  return(result_list)
}
###Data Initialization ########################################
###Data Split


trainingData <- read.table(trainingFile)

testingData <- read.table(testingFile)

colnames(trainingData)=c("Y",paste("x", (1:NumofX), sep=""))
colnames(testingData)=c("Y",paste("x", (1:NumofX), sep=""))

num_train <- nrow(trainingData)
set.seed(1)
trainingData <-trainingData[sample(num_train),]
k_fold <- 3
folds <- cut(seq(1,num_train),breaks=k_fold,labels=FALSE)
res_list <- list()
optimal_step <- rep(0,k_fold)

## cross validation 
for(i in 1:k_fold){
  testIndexes <- which(folds==i,arr.ind=TRUE)
  training_testData <- trainingData[testIndexes, ]
  training_trainData <- trainingData[-testIndexes, ]
  res_list[[i]] <- training_mainfunction(training_trainData,training_testData)
  optimal_step[i] <- as.numeric(which.min(res_list[[i]][["All"]][,2]))
}

## training process
Iter <- round(mean(optimal_step))
M <- Iter
final_res <- training_mainfunction(trainingData,testingData)


## output the results
write.table(final_res[["All"]], file = Outputfile)
write.table(final_res[["ImportantFeatures"]], file = paste(Outputfile,"features",sep="."))
write.table(final_res[["RelativePathwayImportance"]], file = paste(Outputfile,"pathways",sep="."))







