## working directory

read_pathway <- function(fileName) {
  conn <- file(fileName,open="r")
  lines <-readLines(conn)
  pathway_list <- list()
  pathway_name <- c()
  for (i in 1:length(lines)){
    tmp_vector <- strsplit(lines[i],",")[[1]]
    pathway_name <- c(pathway_name,tmp_vector[1])
    pathway_list[[i]] <- strsplit(tmp_vector[2]," ")[[1]]  
    
  }
  close(conn)
  return_list <- list("pathway_name"=pathway_name,"pathway_list"=pathway_list)
  return(return_list)
   
}



convert_features <- function(fileName,pathway_list) {
  conn <- file(fileName,open="r")
  line <-readLines(conn, n = 1)
  gene_list <- strsplit(line,",")[[1]][-1]
  converted_pathlist <- list()
  for (i in 1:length(pathway_list)){
    tmp_vector <- pathway_list[[i]]
    path_x_index <- match(tmp_vector,gene_list)
    path_x_nindex <- path_x_index[!is.na(path_x_index)]
    new_gene_name <- paste("x",path_x_nindex,sep = "")
    converted_pathlist[[i]] <- new_gene_name  
  }
  close(conn)
  return(converted_pathlist)
  
}

files_generation <- function(dataset, cv_num) {
  training_name <- paste("trainingData",cv_num,".txt",sep = "")
  testing_name <- paste("testingData",cv_num,".txt",sep = "")
  if (file.exists(training_name) & file.exists(testing_name)) {
    return(list(training_name=training_name,testing_name=testing_name))
  } else {
    # ruddle version
    raw_exp_file <- paste("../../../../data/",dataset,"/data_expression.txt",sep = "")
    raw_response_file <- paste("../../../../data/",dataset,"/data_response.txt",sep = "")
    test_id_file <- paste("../../../../data/",dataset,"/test_label",cv_num,".txt", sep = "") 
    
    raw_exp_data <- read.table(raw_exp_file, sep = ",", header = T)
    raw_response_data <- read.table(raw_response_file, sep = ",", header = T)
    
    # split the dataset
    all_id <- as.character(raw_response_data[,1])
    test_id <- read.table(test_id_file,header = F)[,1]
    train_id <- setdiff(all_id,test_id)
    
    # testing data extraction
    testing_exp_index <- which(raw_exp_data[,1] %in% test_id)
    testing_res_index <- which(raw_response_data[,1] %in% test_id)
    
    # training data extraction
    training_exp_index <- which(raw_exp_data[,1] %in% train_id)
    training_res_index <- which(raw_response_data[,1] %in% train_id)
    
    # generate the training and testing data
    training_data <- cbind(raw_response_data[,2][training_res_index],raw_exp_data[,-1][training_exp_index,])
    testing_data <- cbind(raw_response_data[,2][testing_res_index],raw_exp_data[,-1][testing_exp_index,])
    
    # save the files
    write.table(training_data,file = training_name, quote = F, col.names = F, row.names = F, sep = " ")
    write.table(testing_data,file = testing_name, quote = F, col.names = F, row.names = F, sep = " ")
  
    return(list(training_name=training_name,testing_name=testing_name))
  
  }  
}
