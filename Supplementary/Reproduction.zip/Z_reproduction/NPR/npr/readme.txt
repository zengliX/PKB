Welcome to use NPR!

A) NPR consists of two files NPRPub.r and NPRmain.r. NPRPub.r is used to set running options. 
NPRmain.r is the main procedure. 	

B) Input data file format
NPR needs two dataset files as input. One is used for training, the other is used as testing.
The two input files are basically a m*n numberic matrix, having the following requirements
	1) space separated 
	2) each row represents a sample
	3) each column represents a feature or class label
	4) the first column is for class label, equal to 1 or -1
	5) the rest columns are for features
	6) feature values should be in numeric format

Two Sample dataset files are given, traningData.txt and testingData.txt.

NPR will assign Y, x1, x2, x3, ..., from left to right, to the names of each column.
You could set the pathway option accordingly in the file NPRPub.r

C) Installation and How to run
	1) Unzip the file into the same directory
	2) prepare the input data files as described in A) and put them into the same directory
	3) Set running options in the file NPRPub.r
	4) Run R
	5) use setwd() to set the working directory as the directory of your unzipped files
	6) source("NPRPub.r")
	
D) Three output files are generated
yourfile describes the training error, the testing error and the selected pathway in each boosting step
yourfile.features file describes feature importance score
yourfile.pathways file describes pathway importance score
Refer to the sample output files SampleOutput, SampleOutput.features and SampleOutput.pathways
