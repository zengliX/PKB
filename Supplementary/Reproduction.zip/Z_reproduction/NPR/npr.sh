#!/bin/bash

# Generate the sbatch scripts
DATA=$1
PY=$2
ITER=1000
JOB=${DATA}_${PY}_${ITER}
DATANAME=${DATA/\//_}

# run the main function
module load R;
source ~/.bashrc;
echo $JOB;
date;
R --slave -f ./npr/NPRPub.r --args $DATA $PY 0 $ITER;
R --slave -f ./npr/NPRPub.r --args $DATA $PY 1 $ITER;
R --slave -f ./npr/NPRPub.r --args $DATA $PY 2 $ITER;
date;
