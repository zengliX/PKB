#!/bin/bash

DIR=$1
cd $DIR
touch ../summary_${DIR}.txt
for i in `ls`;
do cd $i;
echo $i >> ../../summary_${DIR}.txt;
python ../../extract_res.py >> ../summary_${DIR}.txt;
cd ..;
done
