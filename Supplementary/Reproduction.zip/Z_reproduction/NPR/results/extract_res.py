import os
from sys import argv
import numpy as np

optimal_list = []
if os.path.isfile('SampleOutput0.txt'):
        fi1 = open("SampleOutput0.txt","r")
        fi1.readline()
        list1 = []
        for line in fi1:
                list1.append(float(line.strip().split()[2]))
        optimal_list.append(min(list1))
        fi1.close()

if os.path.isfile('SampleOutput1.txt'):
        fi2 = open("SampleOutput1.txt","r")
        fi2.readline()
        list2 = []
        for line in fi2:
                list2.append(float(line.strip().split()[2]))
        optimal_list.append(min(list2))
        fi2.close()

if os.path.isfile('SampleOutput2.txt'):
        fi3 = open("SampleOutput2.txt","r")
        fi3.readline()
        list3 = []
        for line in fi3:
                list3.append(float(line.strip().split()[2]))
        optimal_list.append(min(list3))
        fi3.close()


avg = np.mean(optimal_list)
print(avg)
