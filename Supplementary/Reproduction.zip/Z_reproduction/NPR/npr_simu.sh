#!/bin/bash

# Generate the sbatch scripts
DATA=$1
ITER=1000
JOB=${DATA}_${PY}_${ITER}
DATANAME=${DATA/\//_}

# run the main function
module load R;
source ~/.bashrc;
echo $JOB;
date;
R --slave -f ./npr_simu/NPRPub.r --args $DATA 0 $ITER;
R --slave -f ./npr_simu/NPRPub.r --args $DATA 1 $ITER;
R --slave -f ./npr_simu/NPRPub.r --args $DATA 2 $ITER;
date;
